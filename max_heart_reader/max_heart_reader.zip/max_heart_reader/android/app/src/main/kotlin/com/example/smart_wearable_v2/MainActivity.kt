package com.example.smart_wearable_v2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
