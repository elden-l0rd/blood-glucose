package com.example.air_purifier_v4

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
