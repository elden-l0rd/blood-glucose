package com.example.wearable_watch_v1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
