package com.example.bluetooth_integration_test_3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
