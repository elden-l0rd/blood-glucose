package com.trilogy.technologies.smart.wearable.smart_wearable_v5

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
