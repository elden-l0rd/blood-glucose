package com.example.bluetooth_integration_test_1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
